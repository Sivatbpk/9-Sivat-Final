const { createClient } = require("@supabase/supabase-js");

const supabase = createClient(
  "https://imfrkowkmcjlguijdxff.supabase.co",
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImltZnJrb3drbWNqbGd1aWpkeGZmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzEzOTQ4OTgsImV4cCI6MjA4Njk3MDg5OH0.qltRA1JJcTHMWna1TWBteTL1IlnSmhZDFbhT2jK3DhE"
);

module.exports = supabase;
