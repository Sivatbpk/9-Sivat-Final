async function loadProducts() {
  const res = await fetch("/api/products");
  const data = await res.json();
  console.log(data);
}
