document.addEventListener("DOMContentLoaded", async () => {
  const tableBody = document.querySelector("#productTable");

  const res = await fetch("/api/products");
  const data = await res.json();

  tableBody.innerHTML = "";

  data.forEach((product) => {
    tableBody.innerHTML += `
        <tr>
          <td>${product.name}</td>
          <td>${product.category}</td>
          <td>${product.price}</td>
          <td>${product.stock}</td>
          <td>
            <a href="edit.html?id=${product.id}">แก้ไข</a>
          </td>
        </tr>
      `;
  });
});
