exports.getProducts = async (req, res) => {
  const supabase = require("../config/supabaseClient");
  const { data, error } = await supabase.from("products").select("*");

  if (error) return res.status(400).json(error);
  res.json(data);
};

exports.createProduct = async (req, res) => {
  const supabase = require("../config/supabaseClient");
  const { name, category, price, stock, description } = req.body;

  const { data, error } = await supabase
    .from("products")
    .insert([{ name, category, price, stock, description }]);

  if (error) return res.status(400).json(error);
  res.json(data);
};

exports.updateProduct = async (req, res) => {
  const supabase = require("../config/supabaseClient");
  const { id } = req.params;
  const { name, category, price, stock, description } = req.body;

  const { data, error } = await supabase
    .from("products")
    .update({ name, category, price, stock, description })
    .eq("id", id);

  if (error) return res.status(400).json(error);
  res.json(data);
};

exports.deleteProduct = async (req, res) => {
  const supabase = require("../config/supabaseClient");
  const { id } = req.params;

  const { data, error } = await supabase.from("products").delete().eq("id", id);

  if (error) return res.status(400).json(error);
  res.json(data);
};
